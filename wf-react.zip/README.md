# wf-react #

妇联前端项目

### 构建 ###


```
#!node

npm i

npm start
```

open browser localhost:3000

or build in compression packing

```
#!node

npm run build
```


### dependent ###

* [React](https://facebook.github.io/react/index.html)
* [React-router](https://github.com/reactjs/react-router)
* [redux](http://redux.js.org/)
* [immutable](https://facebook.github.io/immutable-js/)