import React from 'react';
import styles from './AgreementPage.scss';
import DocumentTitle from 'react-document-title'
export default class AgreementPage {
	render() {
		return (
			<DocumentTitle title='用户协议'>
				<div>
					<div className="agreement-page">
						<p>用户协议</p>
						<p>用户协议</p>
						<p>用户协议</p>
						<p>用户协议</p>
					</div>
				</div>
			</DocumentTitle>
		);
	}
}