import React, { Component, PropTypes, findDOMNode } from 'react';
import styles from './ImgShade.scss';

export default class ImgShade extends Component{

	render(){
		return (
			<div className='img-shade'>
				<img src='src/images/youdaofenxiang.png' />
			</div>
			);
	}
}
 