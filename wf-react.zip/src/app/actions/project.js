import config from '../config.js'
import {fetchData} from './fetchData'

export const INIT_FETCH = 'INIT_FETCH'
export function initFetch(cb) {
  return dispatch => {
    return fetch(config.API_REGION).then((response) => {                               // 获取区域信息，包括 regionId
      return response.json()
    }).then((stories) => {
      let regionId = stories.result.data[0]._id
      let openId = localStorage.getItem('acct_openId')
      if(window.location.href.indexOf('signIn') >= 0) {
        if(openId && openId !== 'undefined') {
          //tokenFetch(openId, regionId).then((token) => {
          //  localStorage.setItem('login_token', token.result.data.accessToken)
          //  localStorage.setItem('acct_userId', token.result.data._id)
          //  localStorage.setItem('region_id', stories.result.data[0]._id)
          //})
        }else {
          alert('还未预约该服务！')
        }
        return
      }


      if (openId && openId !== 'undefined') {
        console.info('1')
        console.info('openid:' + openId)
        tokenFetch(openId, regionId).then((token) => {
          localStorage.setItem('login_token', token.result.data.accessToken)
          localStorage.setItem('acct_userId', token.result.data._id)
          localStorage.setItem('region_id', stories.result.data[0]._id)
          getUser(token.result.data._id).then((u) => {
            console.info('12')
            bannerFetch(regionId).then((banner) => {
              indexNewsFetch(regionId).then((news) => {
                moduleFetch(regionId).then((module) => {
                  dispatch({
                    type: INIT_FETCH,
                    json: {
                      region: stories.result.data[0],
                      banner: banner.result.data,
                      news: news.result.data,
                      module: module.result.data,
                      token: token.result.data.accessToken,
                      userId: token.result.data._id,
                      wxUser: u.result.data[0],
                    },
                  })
                }).then(() => {
                  if (cb) {
                    cb(regionId)
                  }
                })
              })
            })
          })
        })
      } else {
        console.info('2')
        let search = window.location.search
        let code
        if (search.indexOf('code') >= 0) {
          code = search.substring(search.indexOf('code=') + 5, search.indexOf('&'))
        } else {
          window.location.href = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx5aa4625b237802e0&redirect_uri=http://chonghua.weixin.3861family.com/index.html&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect'
        }
        //let Htmlhref = window.location.href
        //alert(Htmlhref)
        getOpenId(code).then((result) => {
          if (result.json.openid === undefined) {
            //if (Htmlhref.indexOf('signIn') >= 0) {
            //  window.location.href = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx5aa4625b237802e0&redirect_uri=${Htmlhref}&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect`
            //} else {
              window.location.href = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx5aa4625b237802e0&redirect_uri=http://chonghua.weixin.3861family.com/index.html&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect'
            //}
          } else {
            tokenFetch(result.json.openid, regionId).then((token) => {
              localStorage.setItem('acct_openId', result.json.openid)
              localStorage.setItem('login_token', token.result.data.accessToken)
              console.info('token:' + token.result.data.accessToken)
              localStorage.setItem('acct_userId', token.result.data._id)
              localStorage.setItem('region_id', stories.result.data[0]._id)
              getUser(token.result.data._id).then((u) => {
                if (u.result.data[0] === null || u.result.data[0].nickname === undefined) {
                  console.info('21')
                  getUserInfo(result.json.openid, result.json.access_token).then((user) => {
                    localStorage.setItem('acct_nickname', user.nickname)
                    localStorage.setItem('acct_headimg', user.headimgurl)
                    putUser(token.result.data._id, stories.result.data[0]._id, user, token.result.data.accessToken).then((putResult) => {
                      bannerFetch(regionId).then((banner) => {
                        indexNewsFetch(regionId).then((news) => {
                          moduleFetch(regionId).then((module) => {
                            dispatch({
                              type: INIT_FETCH,
                              json: {
                                region: stories.result.data[0],
                                banner: banner.result.data,
                                news: news.result.data,
                                module: module.result.data,
                                token: token.result.data.accessToken,
                                userId: token.result.data._id,
                                wxUser: user,
                              },
                            })
                          }).then(() => {
                            if (cb) {
                              cb(regionId)
                            }
                          })
                        })
                      })
                    })
                  })
                } else {
                  console.info('3')
                  localStorage.setItem('acct_openId', result.json.openid)
                  bannerFetch(regionId).then((banner) => {
                    indexNewsFetch(regionId).then((news) => {
                      moduleFetch(regionId).then((module) => {
                        dispatch({
                          type: INIT_FETCH,
                          json: {
                            region: stories.result.data[0],
                            banner: banner.result.data,
                            news: news.result.data,
                            module: module.result.data,
                            token: token.result.data.accessToken,
                            userId: token.result.data._id,
                            wxUser: u.result.data[0],
                          },
                        })
                      }).then(() => {
                        if (cb) {
                          cb(regionId)
                        }
                      })
                    })
                  })
                }
              })
            })
          }
        })
      }
    }).catch((err) => {
      console.error(err)
    })
  }
}

export const UPDATE_PROJECT_DATA = 'UPDATE_PROJECT_DATA'
export function updateProjectData(regionId) {
  console.log('regionId:-------' + regionId)
  return dispatch => {
    indexNewsFetch(regionId).then((news) => {
      newsTypeFetch(regionId).then((newsTypes) => {
        console.info(newsTypes)
        dispatch({
          type: UPDATE_PROJECT_DATA,
          json: {
            isfirst: false,
            news: news.result.data,
            newsTypes: newsTypes.result.data,
          },
        })
      }).catch((err) => {
        console.error(err)
      })
    })
  }
}

function bannerFetch(regionId) {                                                        // banner 对应首页 banner 图片
  return fetchData({
    url: `${config.API_GET_DATA}/${regionId}/banner?eq="type=main"&populate="resource"`,
  }).then((response) => {
    return response
  }).catch((err)=> {
    console.error(err)
  })
}

function moduleFetch(regionId) {                                                        // module 对应首页模块
  return fetchData({
    url: `${config.API_GET_DATA}/${regionId}/module`,
  }).then((response) => {
    return response
  }).catch((err)=> {
    console.error(err)
  })
}

function serviceFetch(regionId, userId, token) {                                                        // module 对应首页服务
  return fetchData({
    url: `${config.API_GET_DATA}/${regionId}/services/new?populate="organizer cover tags"`,
    token: token,
  }).then((response) => {
    return response
  }).catch((err)=> {
    console.error(err)
  })
}

function indexNewsFetch(regionId) {
  console.log(`${config.API_GET_DATA}/${regionId}/news?populate="cover newsType"&sort="-praise"&limit="5"`)                                                           // news 对应首页新闻内容
  return fetchData({
    url: `${config.API_GET_DATA}/${regionId}/news?populate="cover newsType"&sort="-praise"&limit="5"`,
  }).then((response) => {
    return response
  }).catch((err)=> {
    console.error(err)
  })
}

function notificationFetch(userId) {                                                          // news 对应首页消息
  return fetchData({
    url: `${config.API_USER}/${userId}/notifications`,
  }).then((response) => {
    return response
  }).catch((err)=> {
    console.error(err)
  })
}

export function tokenFetch(openId, regionId) {
  //alert(window.location)
  return fetchData({
    url: `${config.API_ACCOUNT_SIGNIN}/wechat`,
    type: 'POST',
    data: {
      openId: openId,
      regionId: regionId,
    },
  }).then((response) => {
    return response
  }).catch((err)=> {
    console.error(err)
  })
}

function newsTypeFetch(regionId) {
  //alert(window.location)
  return fetchData({
    url: `${config.API_GET_DATA}/${regionId}/commonTypes?eq="type=news"`,
    type: 'GET',
    data: {
      regionId: regionId,
    },
  }).then((response) => {
    return response
  }).catch((err)=> {
    console.error(err)
  })
}

/**
 * 获取openid
 * @param code
 * @returns {Promise.<T>|*|Promise}
 */
//function getOpenId(code) {
//  try {
//    return fetchData({
//      url:`http://chonghua.wechat.server.3861family.com/app/getOpenId?code=${code}`,
//    }).then((response) => {
//      return response
//    }).catch((err)=> {
//      console.error(err)
//    })
//  } catch (e) {
//    console.error('获取openid失败！' + e.message);
//  }
//}

function getOpenId(code) {
  return new Promise(function (resolve, reject) {
    try {
      let xmlhttp
      if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest()
      }
      else {// code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP")
      }
      xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
          let resText = xmlhttp.responseText
          console.info(resText)
          let data = JSON.parse(resText)
          resolve(data)
        }
      }
      let url = `http://chonghua.wechat.server.3861family.com/app/getOpenId?code=${code}`
      console.info("----url:"+url)
      xmlhttp.open("GET", url, true)
      xmlhttp.send()
    } catch (e) {
      console.error('获取openid失败！' + e.message)
    }
  })
}

/**
 * 获取微信用户信息
 * @param openid
 * @param accessToken
 * @returns {Promise.<T>|*|Promise}
 */
function getUserInfo(openid, accessToken) {
  try {
    return fetch(`http://chonghua.wechat.server.3861family.com/app/getUserInfo?openid=${openid}&access_token=${accessToken}`).then((response) => {
      return response.json()
    }).catch((err)=> {
      console.error(err)
    })
  } catch (e) {
    console.error('获取openid失败！' + e.message);
  }
}

/**
 * 向后台put用户信息
 * @param userId
 * @param regionId
 * @param user
 * @param token
 * @returns {Promise.<T>|*|Promise}
 */
function putUser(userId, regionId, user, token) {
  console.info('nickname:' + user.nickname)
  let address = user.province ? user.province : ' ' + user.city ? user.city : ' '
  return fetchData({
    url: `${config.API_USER}/${userId}`,
    type: 'PUT',
    token: token,
    data: {
      regionId: regionId,
      nickname: user.nickname ? user.nickname : ' ',
      headimgurl: user.headimgurl ? user.headimgurl : ' ',
      address: address,
    },
  }).then((response) => {
    return response
  }).catch((err)=> {
    console.error(err)
  })
}

/**
 * 从后台获取用户信息，验证后台是否有该用户信息
 * @param userId
 * @returns {Promise.<T>|*|Promise}
 */
function getUser(userId) {
  return fetchData({
    url: `${config.API_USER}/${userId}`,
  }).then((response) => {
    return response
  }).catch((err)=> {
    console.error(err)
  })
}